#!/bin/bash
set -e

cd /var/www/html

# Copy .env if not exists
if [ ! -f .env ]; then
    cp .env.example .env
fi

# Generate app key if not set
if grep -q "APP_KEY=$" .env || grep -q "APP_KEY=base64:$" .env || ! grep -q "APP_KEY=base64:" .env; then
    php artisan key:generate --force
fi

# Generate JWT secret if not set
if grep -q "JWT_SECRET=$" .env; then
    php artisan jwt:secret --force
fi

# Wait for database
echo "Waiting for database..."
until php -r "new PDO('mysql:host='.getenv('DB_HOST').';port='.getenv('DB_PORT'), getenv('DB_USERNAME'), getenv('DB_PASSWORD'));" 2>/dev/null; do
    sleep 2
    echo "Still waiting..."
done
echo "Database ready!"

# Run migrations and seeders
php artisan migrate --force
php artisan db:seed --force 2>/dev/null || true

# Clear and cache config
php artisan config:clear
php artisan cache:clear 2>/dev/null || true

# Start Apache
apache2-foreground
