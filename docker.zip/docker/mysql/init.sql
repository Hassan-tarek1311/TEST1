-- هذا الملف بيشتغل تلقائياً أول مرة بتشغّل Docker
-- بيتأكد إن قاعدة البيانات اتعملت صح

CREATE DATABASE IF NOT EXISTS timebee_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

GRANT ALL PRIVILEGES ON timebee_db.* TO 'timebee_user'@'%';

FLUSH PRIVILEGES;
